﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CRUDALL
{
        
     
    public class clsinfo
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BJ7PBU5;Initial Catalog=RAHITECHADO.NET;Integrated Security=True");
        string Gender;

        public int USERID { get; set; }
        public string NAME { get; set; }
        public string CITY { get; set; }
        public string ADDRESS { get; set; }
        public string GENDER { get; set; }


        public clsinfo(string name, string city, string address, string gender)
        {
            NAME = name;
            CITY = city;
            ADDRESS = address;
            GENDER = gender;
        }

        
        public void SAVEDATA()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("userinfo1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FLAG", "SAVEDATA");
            cmd.Parameters.AddWithValue("@NAME", NAME);
            cmd.Parameters.AddWithValue("@CITY", CITY);
            cmd.Parameters.AddWithValue("@ADDRESS", ADDRESS);
            cmd.Parameters.AddWithValue("@GENDER", GENDER);
            cmd.ExecuteNonQuery();
            con.Close();




        }



         public clsinfo(int id, string name, string city)
        {
            USERID = id;
            NAME = name;
            CITY = city;
        }

        public void UPDATEDATA()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("userinfo1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FLAG", "UPDATEDATA");
            cmd.Parameters.AddWithValue("@NAME", NAME);
            cmd.Parameters.AddWithValue("@CITY", CITY);
            cmd.Parameters.AddWithValue("@USERID", USERID);
            cmd.ExecuteNonQuery();
            con.Close();


        }



         public clsinfo(int id)
        {
            USERID = id;
        }

        public void DELETEDATA()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("userinfo1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FLAG", "DELETEDATA");
            cmd.Parameters.AddWithValue("@USERID", USERID);
            cmd.ExecuteNonQuery();
            con.Close();
        }




         public clsinfo()
        {
        }

        public DataTable SHOW()//load//IT IS FOR ONLY SHOW THE DATA 
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("userinfo1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adpt = new SqlDataAdapter(cmd);
            adpt.SelectCommand.Parameters.AddWithValue("@FLAG", "SHOWGRID");
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            return dt;
            con.Close();
        }



        public SqlDataReader Fetch()//show
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("userinfo1", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FLAG", "FETCHDATA");
            cmd.Parameters.AddWithValue("@USERID", USERID);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            return dr;
            con.Close();

        }
    }

}