﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace CRUDALL
{
    public partial class REGISTRATIONFORM : System.Web.UI.Page
    {
        string gender;
        protected void Page_Load(object sender, EventArgs e)
        {
            clsinfo objshow = new clsinfo();
            DataTable dt = new DataTable();
            dt = objshow.SHOW();
            grdvw.DataSource = dt;
            grdvw.DataBind();
        }

        protected void btninsert_Click(object sender, EventArgs e)
        {

            if (rdbmale.Checked == true)
            {
               gender = "male";
            }
            else
                gender = "female";


            clsinfo obj = new clsinfo(txtname.Text,txtcity.Text,txtaddress.Text,gender);
            obj.SAVEDATA();
            Response.Write("<script>alert('Data inserted successfully')</script>");

        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
              int id=Convert.ToInt32(txtid.Text);
            clsinfo OBJUPDATE=new clsinfo(id,txtname.Text,txtcity.Text);
            OBJUPDATE.UPDATEDATA();
         Response.Write("<script>alert('Data updated successfully')</script>");

        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtid.Text);
            clsinfo OBJDELETE = new clsinfo(id);
            OBJDELETE.DELETEDATA();
            Response.Write("<script>alert('Data deleted successfully')</script>");
        }

        protected void btnshow_Click(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(txtid.Text);
            clsinfo objfetch = new clsinfo(id);
            SqlDataReader dr;
            dr = objfetch.Fetch();

            while (dr.Read())
            {
                txtid.Text = dr["USERID"].ToString();
                txtname.Text = dr["NAME"].ToString();
                txtcity.Text = dr["CITY"].ToString();
                txtaddress.Text = dr["ADDRESS"].ToString();
               gender = dr["GENDER"].ToString();

                if (gender == "MALE")
                {
                    rdbmale.Checked = true;
                }
                else
                {
                    rdbfemale.Checked = true;
                }


            }
            dr.Close();
        }
        }
    }
